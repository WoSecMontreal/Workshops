/* 
Critical objects/modules are:

Process
Thread
Interceptor
Stalker
Memory
MemoryAccessMonitor

*/


/* Example of monitoring a specific function */
var modules = Process.enumerateModules(); // Get a list of libraries imported by the process
var kernel32 = modules.find(x => x.name == 'msvcrt.dll'); 
var strcmp = kernel32.getExportByName('strcmp'); 
Interceptor.attach(strcmp, {
    onEnter(args) {
        console.log(`memcmp compared: "${args[0].readCString()}" to "${args[1].readCString()}"`)
    }
});