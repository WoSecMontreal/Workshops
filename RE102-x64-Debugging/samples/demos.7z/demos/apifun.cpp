#include <windows.h>
#include <stdlib.h>
#include <string>
 
int WINAPI WinMain ( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd )
{
    char *buffer = (char*) malloc(255);

    if (buffer == NULL){
        exit(1);
    }

    int i;
    for (i=0; i<254; i++){
        buffer[i] = rand()%26 + 'a';
    }
    buffer[254] = '\0';

    MessageBoxA (NULL, buffer, "Random", MB_OK);

    HANDLE hFile = CreateFile(
      "C:\\re102.txt",     
      GENERIC_WRITE,          
      FILE_SHARE_READ,        
      NULL,                   
      CREATE_NEW,             
      FILE_ATTRIBUTE_NORMAL,  
      NULL);                  
    
    if (hFile == INVALID_HANDLE_VALUE)
    {
        return 2;
    }

    DWORD bytesWritten;
    WriteFile(
        hFile,            
        buffer,  
        255,   
        &bytesWritten,    
        nullptr);         

    CloseHandle(hFile);

    free(buffer);


    return 0;
}