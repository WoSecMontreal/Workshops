#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int simplefunc();

int crazyadd(int a, int b, int c, int d, int e, int f, int g, int h);

void main()
{
        printf("Hello World...\n");

        // loops
        int i;
        for (i = 1; i < 11; ++i){
                printf("%d ", i);
        }

        int val = simplefunc();

        int result = crazyadd(1,2,3,4,5,6,7,8);

        exit(val);
} 

int simplefunc()
{
        printf("So simple!");
        return 0;
}

int crazyadd(int a, int b, int c, int d, int e, int f, int g, int h)
{
        return a + b + c + d + e + f + g + h;
}