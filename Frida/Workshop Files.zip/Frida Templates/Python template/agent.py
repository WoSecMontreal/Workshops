import frida
import sys
from typing import Union
from datetime import datetime


class FridaTool:
    script: Union[frida.core.Script, None]

    def __init__(self, target: Union[int, str], path: str):
        self.target = target
        self.path = path
        self.session = frida.attach(target)
        self.script = None

        print(f"[{datetime.now()}] Loaded into {target}")
        self.load_script()
        print("[!] Ctrl+D on UNIX, Ctrl+Z on Windows/cmd.exe to detach from instrumented program.\n\n")

        monitor = frida.FileMonitor(path)
        monitor.on('change', self.on_file_update)
        monitor.enable()
        self.monitor = monitor

        sys.stdin.read()
        self.session.detach()

    def on_file_update(self, changed_file, other_file, event_type):
        if event_type != 'changes-done-hint':
            return

        print(f"[{datetime.now()}] Script update detected")
        if self.script:
            self.script.unload()
            self.script = None
        self.load_script()

    def load_script(self):
        with open(self.path, 'r') as data:
            try:
                script = self.session.create_script(data.read())
            except frida.InvalidArgumentError:
                print(f"[{datetime.now()}] Tried to load script but it caused an error. Is there a typo in the script?")
                return
            script.on('message', self.on_message)
            script.load()
            self.script = script

    def on_message(self, message, data):
        print(f"[{message}] => {data}")

if __name__ == '__main__':
    if len(sys.argv) != 3:
        print(f"Usage: {__file__} <process name or PID> <script path>")
        sys.exit(1)

    try:
        target_process = int(sys.argv[1])
    except ValueError:
        target_process = sys.argv[1]
    agent = FridaTool(target_process, sys.argv[2])